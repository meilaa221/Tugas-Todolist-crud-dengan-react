import React, { useState, useMemo } from 'react';
import { Button, Card, Form, Container, Row, Col, Modal } from 'react-bootstrap';
import { FaTrash, FaEdit, FaCheckCircle, FaCircle, FaCircleNotch, FaTrashAlt } from 'react-icons/fa';
import './TaskList.css';

const TaskList = ({ tasks, deleteTask, showEditForm }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedStatus, setSelectedStatus] = useState('All');
  const [selectedProgress, setSelectedProgress] = useState('All');
  const [selectedTasks, setSelectedTasks] = useState([]); // Track selected tasks for deletion
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false); // Show confirmation modal

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'High':
        return 'red';
      case 'Medium':
        return 'orange';
      case 'Low':
        return 'green';
      default:
        return 'black';
    }
  };

  const getProgressIcon = (status) => {
    if (status === 'Done') {
      return <FaCheckCircle style={{ color: '#28a745', animation: 'pulse 1s infinite' }} />;
    } else if (status === 'In Progress') {
      return <FaCircleNotch className="progress-icon spin" style={{ color: '#ffc107' }} />;
    } else {
      return <FaCircle style={{ color: '#6c757d', opacity: 0.6 }} />;
    }
  };

  // Memoized filtered tasks to optimize performance
  const filteredTasks = useMemo(() => {
    return tasks.filter((task) => {
      const searchLower = searchTerm.toLowerCase();
      const matchesSearch =
        task.name.toLowerCase().includes(searchLower) ||
        task.priority.toLowerCase().includes(searchLower) ||
        task.status.toLowerCase().includes(searchLower);

      const matchesCategory = selectedCategory === 'All' || task.priority === selectedCategory;
      const matchesStatus = selectedStatus === 'All' || task.status === selectedStatus;
      const matchesProgress =
        selectedProgress === 'All' ||
        (selectedProgress === 'In Progress' && task.status === 'In Progress') ||
        (selectedProgress === 'Done' && task.status === 'Done') ||
        (selectedProgress === 'Not Started' && task.status === 'Not Started');

      return matchesSearch && matchesCategory && matchesStatus && matchesProgress;
    });
  }, [tasks, searchTerm, selectedCategory, selectedStatus, selectedProgress]);

  // Handle task selection for deletion
  const handleSelectTask = (taskId) => {
    setSelectedTasks((prevSelected) =>
      prevSelected.includes(taskId)
        ? prevSelected.filter((id) => id !== taskId) // Remove task from selection
        : [...prevSelected, taskId] // Add task to selection
    );
  };

  const handleDeleteSelected = () => {
    selectedTasks.forEach((taskId) => deleteTask(taskId));
    setSelectedTasks([]); // Clear selection after deletion
    setShowDeleteConfirm(false); // Close confirmation modal
  };

  return (
    <div className="task-list-container">
      {/* Header */}
      <header className="task-list-header">
        <h1>Task Manager</h1>
        <p>Efficiently organize and track your tasks</p>
      </header>

      {/* Search and Filters */}
      <Container className="mb-4">
        <Row>
          <Col md={3} className="mb-3">
            <Form.Control
              type="text"
              placeholder="Search tasks..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="search-input"
            />
          </Col>
          <Col md={3} className="mb-3">
            <Form.Control
              as="select"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="filter-select"
            >
              <option value="All">All Categories</option>
              <option value="High">High Priority</option>
              <option value="Medium">Medium Priority</option>
              <option value="Low">Low Priority</option>
            </Form.Control>
          </Col>
          <Col md={3} className="mb-3">
            <Form.Control
              as="select"
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="filter-select"
            >
              <option value="All">All Statuses</option>
              <option value="To Do">To Do</option>
              <option value="In Progress">In Progress</option>
              <option value="Done">Done</option>
            </Form.Control>
          </Col>
          <Col md={3} className="mb-3">
            <Form.Control
              as="select"
              value={selectedProgress}
              onChange={(e) => setSelectedProgress(e.target.value)}
              className="filter-select"
            >
              <option value="All">All Progress</option>
              <option value="In Progress">In Progress</option>
              <option value="Done">Done</option>
              <option value="Not Started">Not Started</option>
            </Form.Control>
          </Col>
        </Row>
      </Container>

      {/* Task List */}
      <Container>
        {filteredTasks.length > 0 ? (
          filteredTasks.map((task, index) => (
            <Card className="mb-3 task-card" key={index}>
              <Card.Body className="d-flex justify-content-between align-items-center task-row">
                <div className="task-column">
                  <input
                    type="checkbox"
                    checked={selectedTasks.includes(task.id)}
                    onChange={() => handleSelectTask(task.id)}
                    className="delete-checkbox"
                  />
                </div>
                <div className="task-column">
                  <div className="label">Task</div>
                  <div className="content task-name">{task.name}</div>
                </div>
                <div className="task-column">
                  <div className="label">Priority</div>
                  <div
                    className="content priority"
                    style={{ color: getPriorityColor(task.priority) }}
                  >
                    {task.priority}
                  </div>
                </div>
                <div className="task-column">
                  <div className="label">Status</div>
                  <div className="content status-badge">
                    <span
                      className={`badge bg-${
                        task.status === 'Done'
                          ? 'success'
                          : task.status === 'In Progress'
                          ? 'warning'
                          : 'secondary'
                      }`}
                    >
                      {task.status}
                    </span>
                  </div>
                </div>
                <div className="task-column">
                  <div className="label">Progress</div>
                  <div className="content progress-icon">{getProgressIcon(task.status)}</div>
                </div>
                <div className="actions">
                  <Button variant="link" onClick={() => showEditForm(task)} className="edit-button">
                    <FaEdit />
                  </Button>
                  {/* Individual Delete Button */}
                  <Button
                    variant="link"
                    onClick={() => deleteTask(task.id)}
                    className="delete-button"
                  >
                    <FaTrash />
                  </Button>
                </div>
              </Card.Body>
            </Card>
          ))
        ) : (
          <div className="text-center">
            <i className="empty-state-icon fa fa-tasks" />
            <p className="text-muted">No tasks available. Add new tasks to get started!</p>
          </div>
        )}

        {/* Delete Button for Batch Deletion */}
        {selectedTasks.length > 0 && (
          <Button
            variant="danger"
            onClick={() => setShowDeleteConfirm(true)}
            className="mt-3"
          >
            <FaTrashAlt /> Delete Selected
          </Button>
        )}
      </Container>

      {/* Confirmation Modal */}
      <Modal
        show={showDeleteConfirm}
        onHide={() => setShowDeleteConfirm(false)}
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title>Confirm Deletion</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>Are you sure you want to delete the selected tasks?</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeleteConfirm(false)}>
            Cancel
          </Button>
          <Button variant="danger" onClick={handleDeleteSelected}>
            Confirm
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default TaskList;
