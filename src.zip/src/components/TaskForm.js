import React, { useState, useEffect } from 'react';
import { Button, Form, Modal, Row, Col } from 'react-bootstrap';

const TaskForm = ({ show, handleClose, addTask, editTask, taskToEdit }) => {
    const [task, setTask] = useState({ name: '', priority: 'Medium', status: 'To Do' });
    const [errors, setErrors] = useState({}); // State untuk validasi error

    useEffect(() => {
        if (taskToEdit) {
            setTask(taskToEdit);
        } else {
            setTask({ name: '', priority: 'Medium', status: 'To Do' });
        }
    }, [taskToEdit]);

    const handleChange = (e) => {
        setTask({ ...task, [e.target.name]: e.target.value });
    };

    const validateForm = () => {
        const newErrors = {};
        if (!task.name.trim()) newErrors.name = 'Task name is required';
        if (!task.priority) newErrors.priority = 'Priority must be selected';
        if (!task.status) newErrors.status = 'Status must be selected';
        return newErrors;
    };

    const handleSubmit = () => {
        const validationErrors = validateForm();
        if (Object.keys(validationErrors).length > 0) {
            setErrors(validationErrors);
        } else {
            taskToEdit ? editTask(task) : addTask(task);
            setTask({ name: '', priority: 'Medium', status: 'To Do' });
            handleClose();
        }
    };

    return (
        <Modal show={show} onHide={handleClose} centered>
            <Modal.Header closeButton>
                <Modal.Title>{taskToEdit ? 'Edit Task' : 'Add Task'}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Form>
                    {/* Task Name */}
                    <Form.Group controlId="taskName">
                        <Form.Label>Task</Form.Label>
                        <Form.Control
                            type="text"
                            name="name"
                            value={task.name}
                            onChange={handleChange}
                            placeholder="Enter task name"
                            isInvalid={!!errors.name}
                        />
                        <Form.Text muted>Provide a clear and concise name for the task.</Form.Text>
                        <Form.Control.Feedback type="invalid">
                            {errors.name}
                        </Form.Control.Feedback>
                    </Form.Group>

                    <Row>
                        <Col sm={6}>
                            {/* Priority */}
                            <Form.Group controlId="taskPriority" className="mt-3">
                                <Form.Label>Priority</Form.Label>
                                <Form.Control
                                    as="select"
                                    name="priority"
                                    value={task.priority}
                                    onChange={handleChange}
                                    isInvalid={!!errors.priority}
                                >
                                    <option value="">Select priority</option>
                                    <option>Low</option>
                                    <option>Medium</option>
                                    <option>High</option>
                                </Form.Control>
                                <Form.Control.Feedback type="invalid">
                                    {errors.priority}
                                </Form.Control.Feedback>
                            </Form.Group>
                        </Col>
                        <Col sm={6}>
                            {/* Status */}
                            <Form.Group controlId="taskStatus" className="mt-3">
                                <Form.Label>Status</Form.Label>
                                <Form.Control
                                    as="select"
                                    name="status"
                                    value={task.status}
                                    onChange={handleChange}
                                    isInvalid={!!errors.status}
                                >
                                    <option value="">Select status</option>
                                    <option>To Do</option>
                                    <option>In Progress</option>
                                    <option>Done</option>
                                </Form.Control>
                                <Form.Control.Feedback type="invalid">
                                    {errors.status}
                                </Form.Control.Feedback>
                            </Form.Group>
                        </Col>
                    </Row>
                </Form>
            </Modal.Body>
            <Modal.Footer>
                <Button
                    variant="secondary"
                    onClick={handleClose}
                    className="rounded-pill px-4"
                >
                    Cancel
                </Button>
                <Button
                    variant="primary"
                    onClick={handleSubmit}
                    className="rounded-pill px-4"
                >
                    {taskToEdit ? 'Update Task' : 'Add Task'}
                </Button>
            </Modal.Footer>
        </Modal>
    );
};

export default TaskForm;
